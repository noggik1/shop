<div class="container mt-3 text-center">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <img src="https://media.discordapp.net/attachments/942998454945341500/957984913645252608/giftcode_1.png">
                    <div class="mt-2">
                        <input class="form-control" id="pass_code" placeholder="กรุณากรอกรหัสโค๊ด">
                    </div>
                    <div class="mt-2">
                        <p class="text-danger">สามารถรับได้ที่ Discord</p>
                    </div>
                    <div class="mt-2">
                        <button type="button" class="btn btn-success w-100" id="submit_code">ตรวจสอบการทำรายการ</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../../assets/js/code.js"></script>